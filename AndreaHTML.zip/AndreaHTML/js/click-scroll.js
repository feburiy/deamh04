$(document).ready(function () {
  var sectionArray = [1, 2, 3, 4, 5];
  var navLinks = $('.navbar-nav .nav-item .nav-link');
  var clickScrollLinks = $('.click-scroll');
  var scrollTimeout;

  // Function to update navigation links based on scroll position
  function updateNavLinks() {
    var docScroll = $(document).scrollTop();
    var activeSectionIndex = -1;

    sectionArray.forEach(function (value, index) {
      var offsetSection = $('#section_' + value).offset().top - 75;
      if (docScroll >= offsetSection) {
        activeSectionIndex = index;
      }
    });

    navLinks.removeClass('active').addClass('inactive');
    if (activeSectionIndex !== -1) {
      navLinks.eq(activeSectionIndex).addClass('active').removeClass('inactive');
    }
  }

  // Scroll event listener with throttling
  $(document).scroll(function () {
    clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(updateNavLinks, 100); // Adjust the delay as needed
  });

  // Click event listener for smooth scrolling
  clickScrollLinks.click(function (e) {
    e.preventDefault();
    var targetValue = $(this).data('target');
    var offsetClick = $('#section_' + targetValue).offset().top - 75;

    $('html, body').animate({ scrollTop: offsetClick }, 300);
  });

  // Initial setup
  navLinks.addClass('inactive');
  navLinks.eq(0).addClass('active').removeClass('inactive');

  // Call updateNavLinks initially
  updateNavLinks();
});
